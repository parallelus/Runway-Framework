<?php 
// Translation strings
__('Other Content', 'framework');
__('Headers and Footers', 'framework');
__('Header', 'framework');
__('Header Content', 'framework');
__('Footers', 'framework');
__('Footer Content', 'framework');
__('Set the header and footer content.', 'framework');
__('The content to appear in the header below the logo and menu.', 'framework');
__('The content to appear in the footer.', 'framework');
?>